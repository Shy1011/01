[IIC协议学习笔记 - 知乎](https://zhuanlan.zhihu.com/p/34674402)

[IIC通信（上）](https://www.bilibili.com/video/BV153411j78g/?share_source=copy_web&vd_source=6d2f18af1a0650808533148055723b16)