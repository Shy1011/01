[SPI通信协议详解（spi总线） - 知乎](https://zhuanlan.zhihu.com/p/150121520)

- **SPI，是一种高速的，全双工，同步的通信总线**
- 只占用了四根引脚
![](assets/截图_20231004140931.png)

# 极性和相位
![](assets/截图_20231004141237.png)

![](assets/截图_20231004141240.png)

![](assets/截图_20231004141244.png)

![](assets/Pasted%20image%2020231004141409.png)